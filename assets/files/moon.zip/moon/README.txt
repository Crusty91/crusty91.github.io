
TITLE: 
Moon - 100% Fully Responsive Multipurpose HTML5 Bootstrap 4 Template

AUTHOR:
DESIGNED & DEVELOPED by GetTemplates.co and FreeHTML5.co

Websites: https://gettemplates.co http://freehtml5.co/


CREDITS:

Bootstrap
http://getbootstrap.com/

jQuery
http://jquery.com/

OwlCarousel
https://owlcarousel2.github.io/OwlCarousel2/

Isotope
https://isotope.metafizzy.co

Lightcase
https://cornel.bopp-art.com/lightcase/

Waypoints
http://imakewebthings.com/waypoints/

jQuery countTo
https://github.com/mhuggins/jquery-countTo

Demo Images:
http://unsplash.com

